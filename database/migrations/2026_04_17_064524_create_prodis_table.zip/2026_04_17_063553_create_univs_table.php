<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('univs', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('kode_univ');
            $table->string('nama_univ');
            $table->string('nama_pimpinan');
            $table->string('sign');
            $table->text('address');
            $table->string('email');
            $table->string('website');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('univs');
    }
};
